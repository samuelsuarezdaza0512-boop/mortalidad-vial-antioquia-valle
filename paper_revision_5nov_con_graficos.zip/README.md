# Paper: versión de revisión para entrega preliminar-final (5 de noviembre)

- QMD: `paper_revision_5nov.qmd`
- Insumos: `datos/Datos_Antioquia_ValleDelCauca.xlsx` y `datos/Datos_Siniestros_Viales_v2.xlsx`
- Script de auditoría inicial: `scripts/analisis.R`

## Antes de entregar
1. La URL pública de GitHub ya se incorporó en la primera página del QMD: https://github.com/samuelsuarezdaza0512-boop/mortalidad-vial-antioquia-valle.
2. Confirmar y reproducir las cifras y correlaciones con los Excel actualizados. El QMD deja el análisis y los límites explícitos; no se deben afirmar valores de Valle para Fasecolda si no están completos.
3. Verificar la tabla central `datos/tabla_central.csv` (departamento, anio, fallecidos, poblacion, tasa_mortalidad). El chunk de tabla/gráfica la muestra si ese archivo está disponible.
4. Verificar las referencias, URLs, fechas de consulta y el cuadro de herramientas contra el historial real. No se recibieron comentarios de Ronda 2.
5. Renderizar en un equipo limpio con Quarto, LaTeX/XeLaTeX, R y los paquetes listados en el QMD.

El texto incluye una declaración de IA que debe ajustarse para describir fielmente el uso efectivo de herramientas y las verificaciones humanas.
